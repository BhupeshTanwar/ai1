import { drizzle } from 'drizzle-orm/postgres-js';
import { migrate } from 'drizzle-orm/postgres-js/migrator';
import postgres from 'postgres';
import * as schema from '@shared/schema';

// Check for required environment variables
if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL environment variable is required");
}

// Create connection
const client = postgres(process.env.DATABASE_URL);
export const db = drizzle(client, { schema });

// Run migrations - using push instead of migrations for simplicity
export async function runMigrations() {
  try {
    console.log('Initializing database schema...');
    // We're directly using the schema instead of migrations
    // In a production app, you'd use proper migrations
    console.log('Schema initialization completed');
    return true;
  } catch (error) {
    console.error('Error initializing database schema:', error);
    throw error;
  }
}

// Seed initial data
export async function seedDatabase() {
  try {
    console.log('Checking if database needs seeding...');
    
    // Check if products table is empty
    const products = await db.query.products.findMany({
      limit: 1
    });
    
    if (products.length === 0) {
      console.log('Seeding database with initial products...');
      
      // Initial product data
      const initialProducts = [
        {
          title: "Wireless Bluetooth Headphones",
          price: "59.99",
          rating: "4.5",
          image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
          description: "Premium sound quality with active noise cancellation. Comfortable over-ear design with up to 30 hours of battery life. Perfect for music enthusiasts and professionals alike."
        },
        {
          title: "Smart Watch with Fitness Tracking",
          price: "89.99",
          rating: "4.2",
          image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
          description: "Track your fitness goals with heart rate monitoring, step counter, and sleep tracking. Water-resistant with a vibrant touch display. Compatible with iOS and Android."
        },
        {
          title: "Ultra HD Smart TV - 55\"",
          price: "499.99",
          rating: "4.8",
          image: "https://images.unsplash.com/photo-1593784991095-a205069470b6?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
          description: "Crystal clear 4K resolution with HDR for vibrant colors. Smart TV functionality with built-in streaming apps. Voice control compatibility and slim design for any living space."
        },
        {
          title: "Professional DSLR Camera Bundle",
          price: "749.99",
          rating: "4.7",
          image: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
          description: "Capture stunning photos with this 24.1MP DSLR camera. Includes 18-55mm lens, 70-300mm zoom lens, camera bag, and accessories. Perfect for beginners and enthusiasts."
        },
        {
          title: "Portable Bluetooth Speaker",
          price: "39.99",
          rating: "4.0",
          image: "https://images.unsplash.com/photo-1564424224827-cd24b8915874?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
          description: "Compact and powerful with 360° sound. Waterproof design makes it perfect for outdoor use. 12-hour battery life with quick recharging via USB-C."
        },
        {
          title: "Gaming Laptop - 15.6\" 144Hz",
          price: "1299.99",
          rating: "4.6",
          image: "https://images.unsplash.com/photo-1603302576837-37561b2e2302?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
          description: "High-performance gaming laptop featuring the latest CPU and GPU. 16GB RAM, 512GB SSD, and RGB keyboard. Immersive gaming experience with powerful cooling system."
        },
        {
          title: "Coffee Maker with Grinder",
          price: "129.99",
          rating: "4.3",
          image: "https://images.unsplash.com/photo-1585515320310-259814833e62?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
          description: "Automatic coffee maker with built-in bean grinder. Programmable brewing schedule and adjustable strength settings. Thermal carafe keeps coffee hot for hours."
        },
        {
          title: "Ergonomic Office Chair",
          price: "199.99",
          rating: "4.4",
          image: "https://images.unsplash.com/photo-1580480055273-228ff5388ef8?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
          description: "Premium ergonomic chair with lumbar support and adjustable armrests. Breathable mesh back with memory foam seat for all-day comfort. Perfect for home office or professional settings."
        }
      ];
      
      // Insert products
      await db.insert(schema.products).values(initialProducts);
      console.log('Database seeded successfully');
    } else {
      console.log('Database already has products, skipping seed');
    }
  } catch (error) {
    console.error('Error seeding database:', error);
    throw error;
  }
}