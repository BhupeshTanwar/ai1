import { 
  users, 
  products,
  type User, 
  type InsertUser, 
  type Product as SchemaProduct,
  type InsertProduct,
  eq,
  or,
  like
} from "@shared/schema";
import { db } from "./db";

// Define product type with numeric price and rating for the frontend
interface Product extends Omit<SchemaProduct, 'price' | 'rating'> {
  id: number;
  title: string;
  price: number;
  description: string;
  image: string;
  rating: number;
}

// Extended storage interface
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  searchProducts(query: string): Promise<Product[]>;
}

// Make sure we export our Product interface
export type { Product };

// Database storage implementation
export class DbStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }
  
  // Product methods
  async getAllProducts(): Promise<Product[]> {
    const dbProducts = await db.select().from(products);
    
    // Convert string prices and ratings to numbers for the frontend
    return dbProducts.map(product => ({
      ...product,
      price: parseFloat(product.price.toString()),
      rating: parseFloat(product.rating.toString())
    }));
  }
  
  async getProductById(id: number): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
    
    if (!result.length) {
      return undefined;
    }
    
    // Convert price and rating to numbers
    const product = result[0];
    return {
      ...product,
      price: parseFloat(product.price.toString()),
      rating: parseFloat(product.rating.toString())
    };
  }
  
  async searchProducts(query: string): Promise<Product[]> {
    query = `%${query.toLowerCase()}%`;
    
    const dbProducts = await db.select()
      .from(products)
      .where(
        or(
          like(products.title, query),
          like(products.description, query)
        )
      );
    
    // Convert price and rating to numbers
    return dbProducts.map(product => ({
      ...product,
      price: parseFloat(product.price.toString()),
      rating: parseFloat(product.rating.toString())
    }));
  }
}

// Create and export the storage instance
export const storage = new DbStorage();
