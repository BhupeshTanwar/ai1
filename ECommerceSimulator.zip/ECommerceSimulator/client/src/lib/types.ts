// Import types from schema
import type { Product as SchemaProduct } from "@shared/schema";

// Re-export types for use in frontend with proper numeric handling
export interface Product extends Omit<SchemaProduct, 'price' | 'rating'> {
  price: number;
  rating: number;
}

// Cart item type for frontend
export interface CartItem {
  product: Product;
  quantity: number;
}
