import { Product, CartItem } from "./types";
export type { CartItem };

// Cart storage interface
export interface CartStorage {
  getItems: () => CartItem[];
  addItem: (product: Product, quantity: number) => void;
  updateItem: (product: Product, quantity: number) => void;
  removeItem: (product: Product) => void;
  clear: () => void;
}

// Local storage cart implementation
export const localStorageCart: CartStorage = {
  getItems: () => {
    try {
      const cartJson = localStorage.getItem("cart");
      if (!cartJson) return [];
      
      // Parse the cart items from JSON
      const rawItems = JSON.parse(cartJson);
      
      // Ensure the product price and rating are converted to numbers
      return rawItems.map((item: any) => ({
        product: {
          ...item.product,
          id: Number(item.product.id),
          price: typeof item.product.price === 'string' 
            ? parseFloat(item.product.price) 
            : Number(item.product.price),
          rating: typeof item.product.rating === 'string' 
            ? parseFloat(item.product.rating) 
            : Number(item.product.rating)
        },
        quantity: Number(item.quantity)
      }));
    } catch (error) {
      console.error("Error retrieving cart from localStorage:", error);
      return [];
    }
  },
  
  addItem: (product: Product, quantity: number) => {
    try {
      const items = localStorageCart.getItems();
      const existingItemIndex = items.findIndex(item => item.product.id === product.id);
      
      if (existingItemIndex !== -1) {
        // Update quantity if item exists
        items[existingItemIndex].quantity += quantity;
      } else {
        // Add new item
        items.push({ 
          product: {
            ...product,
            price: Number(product.price),
            rating: Number(product.rating)
          }, 
          quantity 
        });
      }
      
      localStorage.setItem("cart", JSON.stringify(items));
    } catch (error) {
      console.error("Error adding item to cart:", error);
    }
  },
  
  updateItem: (product: Product, quantity: number) => {
    try {
      const items = localStorageCart.getItems();
      const existingItemIndex = items.findIndex(item => item.product.id === product.id);
      
      if (existingItemIndex !== -1) {
        items[existingItemIndex].quantity = quantity;
        localStorage.setItem("cart", JSON.stringify(items));
      }
    } catch (error) {
      console.error("Error updating cart item:", error);
    }
  },
  
  removeItem: (product: Product) => {
    try {
      const items = localStorageCart.getItems();
      const filteredItems = items.filter(item => item.product.id !== product.id);
      localStorage.setItem("cart", JSON.stringify(filteredItems));
    } catch (error) {
      console.error("Error removing item from cart:", error);
    }
  },
  
  clear: () => {
    try {
      localStorage.removeItem("cart");
    } catch (error) {
      console.error("Error clearing cart:", error);
    }
  }
};
