import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/Header";
import { ProductGrid } from "@/components/ProductGrid";
import { ProductDetail } from "@/components/ProductDetail";
import { Product } from "@/lib/types";
import { useCart } from "@/context/CartContext";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { addToCart } = useCart();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch products from the API
  const { data: products, isLoading, error } = useQuery({
    queryKey: ["/api/products"],
  });

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleAddToCart = (product: Product) => {
    addToCart(product, 1);
  };

  const handleViewProduct = (product: Product) => {
    setSelectedProduct(product);
    setIsProductModalOpen(true);
  };

  const closeProductModal = () => {
    setIsProductModalOpen(false);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onSearch={handleSearch} onToggleCart={() => {/* Cart removed */}} />
      
      <main className="container mx-auto px-4 py-6 flex-grow">
        {/* Banner */}
        <div className="mb-6 rounded-lg overflow-hidden shadow-md">
          <img 
            src="https://images.unsplash.com/photo-1607082349566-187342175e2f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=300" 
            alt="Special deals on electronics banner" 
            className="w-full h-40 md:h-64 object-cover" 
          />
        </div>
        
        {/* Products Section */}
        {isLoading ? (
          <div className="mb-6">
            <Skeleton className="h-8 w-64 mb-6" />
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, index) => (
                <div key={index} className="bg-white rounded-lg shadow p-4">
                  <Skeleton className="h-48 w-full mb-4" />
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/4 mb-2" />
                  <Skeleton className="h-6 w-1/3 mb-3" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ))}
            </div>
          </div>
        ) : error ? (
          <div className="text-center py-10 text-red-500">
            Error loading products. Please try again later.
          </div>
        ) : (
          <ProductGrid 
            products={Array.isArray(products) ? products : []} 
            searchQuery={searchQuery}
            onAddToCart={handleAddToCart}
            onViewProduct={handleViewProduct}
          />
        )}
      </main>
      
      {/* Product Detail Modal */}
      <ProductDetail 
        product={selectedProduct} 
        isOpen={isProductModalOpen} 
        onClose={closeProductModal} 
      />
    </div>
  );
}
