import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Product, CartItem } from "@/lib/types";
import { localStorageCart } from "@/lib/cart";
import { useToast } from "@/hooks/use-toast";

interface CartContextType {
  cart: CartItem[];
  addToCart: (product: Product, quantity: number) => void;
  removeFromCart: (product: Product) => void;
  updateQuantity: (product: Product, quantity: number) => void;
  clearCart: () => void;
  getTotalItems: () => number;
  getTotal: () => number;
}

const CartContext = createContext<CartContextType>({
  cart: [],
  addToCart: () => {},
  removeFromCart: () => {},
  updateQuantity: () => {},
  clearCart: () => {},
  getTotalItems: () => 0,
  getTotal: () => 0,
});

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const { toast } = useToast();

  // Load cart from local storage on initial render
  useEffect(() => {
    try {
      const savedCart = localStorageCart.getItems();
      setCart(savedCart);
    } catch (error) {
      console.error("Error loading cart from localStorage:", error);
    }
  }, []);

  const addToCart = (product: Product, quantity: number) => {
    try {
      // Check if item already exists in cart
      const existingItem = cart.find(item => item.product.id === product.id);
      
      if (existingItem) {
        // Update quantity if item exists
        const newQuantity = existingItem.quantity + quantity;
        updateQuantity(product, newQuantity);
      } else {
        // Add new item
        const newCart = [...cart, { product, quantity }];
        setCart(newCart);
        localStorageCart.addItem(product, quantity);
      }
      
      toast({
        title: "Added to cart",
        description: `${product.title} (Qty: ${quantity}) has been added to your cart.`,
        duration: 2000,
      });
    } catch (error) {
      console.error("Error adding item to cart:", error);
      toast({
        title: "Error",
        description: "Could not add item to cart. Please try again.",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  const removeFromCart = (product: Product) => {
    try {
      const newCart = cart.filter(item => item.product.id !== product.id);
      setCart(newCart);
      localStorageCart.removeItem(product);
      
      toast({
        title: "Removed from cart",
        description: `${product.title} has been removed from your cart.`,
        duration: 2000,
      });
    } catch (error) {
      console.error("Error removing item from cart:", error);
      toast({
        title: "Error",
        description: "Could not remove item from cart. Please try again.",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  const updateQuantity = (product: Product, quantity: number) => {
    try {
      const newCart = cart.map(item => 
        item.product.id === product.id ? { ...item, quantity } : item
      );
      setCart(newCart);
      localStorageCart.updateItem(product, quantity);
    } catch (error) {
      console.error("Error updating cart item quantity:", error);
      toast({
        title: "Error",
        description: "Could not update item quantity. Please try again.",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  const clearCart = () => {
    try {
      setCart([]);
      localStorageCart.clear();
    } catch (error) {
      console.error("Error clearing cart:", error);
    }
  };

  const getTotalItems = () => {
    try {
      return cart.reduce((total, item) => total + item.quantity, 0);
    } catch (error) {
      console.error("Error calculating total items:", error);
      return 0;
    }
  };

  const getTotal = () => {
    try {
      return cart.reduce(
        (total, item) => {
          const price = typeof item.product.price === 'string' 
            ? parseFloat(item.product.price) 
            : item.product.price;
          return total + (price * item.quantity);
        },
        0
      );
    } catch (error) {
      console.error("Error calculating total price:", error);
      return 0;
    }
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        getTotalItems,
        getTotal,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
