import { useState } from "react";
import { X, Star, StarHalf } from "lucide-react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogClose
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Product } from "@/lib/types";
import { useCart } from "@/context/CartContext";

interface ProductDetailProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export function ProductDetail({ product, isOpen, onClose }: ProductDetailProps) {
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState("1");

  if (!product) return null;

  const handleAddToCart = () => {
    addToCart(product, parseInt(quantity));
  };

  // Generate star rating
  const renderStarRating = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const stars = [];
    
    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="w-5 h-5 fill-yellow-400 text-yellow-400" />);
    }
    
    // Add half star if needed
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="w-5 h-5 fill-yellow-400 text-yellow-400" />);
    }
    
    // Add empty stars
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="w-5 h-5 text-yellow-400" />);
    }
    
    return stars;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
        <DialogHeader className="flex justify-between items-start">
          <DialogTitle className="text-xl font-bold">{product.title}</DialogTitle>
          <DialogClose asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <X className="h-4 w-4" />
            </Button>
          </DialogClose>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
          <div>
            <img 
              src={product.image} 
              alt={product.title} 
              className="w-full rounded-lg object-contain max-h-[400px]" 
            />
          </div>
          <div>
            <div className="flex items-center mb-2">
              {renderStarRating(product.rating)}
              <span className="ml-2">{product.rating}</span>
            </div>
            <div className="text-2xl amazon-price mb-2">${product.price.toFixed(2)}</div>
            <div className="amazon-success font-medium mb-4">In Stock</div>
            
            <div className="mb-4">
              <label className="block text-gray-700 mb-2">Quantity:</label>
              <Select
                value={quantity}
                onValueChange={setQuantity}
              >
                <SelectTrigger className="w-24">
                  <SelectValue placeholder="1" />
                </SelectTrigger>
                <SelectContent>
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                    <SelectItem key={num} value={num.toString()}>
                      {num}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-3">
              <Button 
                className="w-full amazon-accent font-bold"
                onClick={handleAddToCart}
              >
                Add to Cart
              </Button>
              <Button className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold">
                Buy Now
              </Button>
            </div>
            
            <div className="mt-6">
              <h3 className="font-bold mb-2">About this item</h3>
              <p className="text-gray-700">{product.description}</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
