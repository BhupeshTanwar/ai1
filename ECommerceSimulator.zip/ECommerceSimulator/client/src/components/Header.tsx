import { useState, useRef, useEffect } from "react";
import { Link } from "wouter";
import { ShoppingCart, Search, Menu, LogIn, UserRound, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/hooks/useAuth";
import { AuthModal } from "./Auth/AuthModal";

interface HeaderProps {
  onSearch: (query: string) => void;
  onToggleCart: () => void;
}

export function Header({ onSearch, onToggleCart }: HeaderProps) {
  const { user, isAuthenticated, logout } = useAuth();
  const { getTotalItems } = useCart();
  const [searchQuery, setSearchQuery] = useState("");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalView, setAuthModalView] = useState<"login" | "signup">("login");
  const searchInputRef = useRef<HTMLInputElement>(null);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch(searchQuery);
    }
  };

  const handleOpenAuthModal = (view: "login" | "signup") => {
    setAuthModalView(view);
    setIsAuthModalOpen(true);
  };

  const handleLogout = async () => {
    await logout();
  };

  const cartCount = getTotalItems();

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === "/" && e.ctrlKey) {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };

    document.addEventListener("keydown", handleKeyPress);
    return () => document.removeEventListener("keydown", handleKeyPress);
  }, []);

  return (
    <header className="sticky top-0 z-30">
      <div className="amazon-primary py-2 px-4">
        <div className="container mx-auto flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <div className="text-[#febd69] text-2xl font-bold flex items-center">
              <ShoppingCart className="mr-2" />
              <span>AmaStore</span>
            </div>
          </Link>
          
          {/* Search Bar - Hidden on mobile */}
          <div className="hidden md:flex flex-1 mx-6 max-w-3xl">
            <form onSubmit={handleSearch} className="w-full relative">
              <Input
                ref={searchInputRef}
                type="text"
                placeholder="Search products... (Ctrl + /)"
                className="w-full rounded-md py-2 pl-4 pr-10 text-black"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button
                type="submit"
                className="absolute right-0 top-0 h-full px-4 amazon-accent rounded-r-md"
              >
                <Search className="h-4 w-4" />
              </Button>
            </form>
          </div>
          
          {/* Navigation and Cart */}
          <div className="flex items-center space-x-4 md:space-x-6">
            {isAuthenticated ? (
              <div className="hidden md:block text-sm">
                <div className="text-gray-300">Hello,</div>
                <div className="font-bold flex items-center">
                  <UserRound className="h-4 w-4 mr-1" />
                  <span>{user?.username}</span>
                </div>
              </div>
            ) : (
              <div className="hidden md:block text-sm cursor-pointer" onClick={() => handleOpenAuthModal("login")}>
                <div className="text-gray-300">Hello, Sign in</div>
                <div className="font-bold flex items-center">
                  <LogIn className="h-4 w-4 mr-1" />
                  <span>Account</span>
                </div>
              </div>
            )}
            
            {isAuthenticated ? (
              <Button
                variant="ghost"
                onClick={handleLogout}
                className="hidden md:flex text-white items-center space-x-1 p-0"
              >
                <LogOut className="h-4 w-4" />
                <span>Sign Out</span>
              </Button>
            ) : (
              <Button
                variant="ghost"
                onClick={() => handleOpenAuthModal("signup")}
                className="hidden md:flex text-white items-center space-x-1 p-0"
              >
                <UserRound className="h-4 w-4" />
                <span>Sign Up</span>
              </Button>
            )}
            
            <Button
              variant="ghost"
              onClick={onToggleCart}
              className="text-[#febd69] relative p-0"
            >
              <ShoppingCart className="h-6 w-6" />
              <span className="ml-1">Cart</span>
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-[#b12704] text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Button>
            
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              className="md:hidden text-white"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              <Menu className="h-6 w-6" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Mobile Search Bar - Shown when menu is open */}
      <div className={cn("amazon-primary py-2 px-4 md:hidden", !isMobileMenuOpen && "hidden")}>
        <form onSubmit={handleSearch} className="w-full relative">
          <Input
            type="text"
            placeholder="Search products..."
            className="w-full rounded-md py-2 pl-4 pr-10 text-black"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Button
            type="submit"
            className="absolute right-0 top-0 h-full px-4 amazon-accent rounded-r-md"
          >
            <Search className="h-4 w-4" />
          </Button>
        </form>
        
        {/* Mobile Auth Buttons */}
        <div className="mt-2 flex justify-center space-x-4">
          {isAuthenticated ? (
            <>
              <div className="text-white text-sm">
                Hello, <span className="font-bold">{user?.username}</span>
              </div>
              <Button
                variant="ghost"
                onClick={handleLogout}
                className="text-white text-sm h-auto p-0"
              >
                Sign Out
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="ghost"
                onClick={() => handleOpenAuthModal("login")}
                className="text-white text-sm h-auto p-0"
              >
                Sign In
              </Button>
              <Button
                variant="ghost"
                onClick={() => handleOpenAuthModal("signup")}
                className="text-white text-sm h-auto p-0"
              >
                Sign Up
              </Button>
            </>
          )}
        </div>
      </div>
      
      {/* Sub Navigation */}
      <div className="amazon-secondary py-1 px-4 text-sm hidden md:block">
        <div className="container mx-auto flex space-x-4">
          <a href="#" className="text-white hover:text-[#febd69]">All</a>
          <a href="#" className="text-white hover:text-[#febd69]">Today's Deals</a>
          <a href="#" className="text-white hover:text-[#febd69]">Customer Service</a>
          <a href="#" className="text-white hover:text-[#febd69]">Gift Cards</a>
          <a href="#" className="text-white hover:text-[#febd69]">Registry</a>
          <a href="#" className="text-white hover:text-[#febd69]">Sell</a>
        </div>
      </div>
      
      {/* Auth Modal */}
      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
        defaultView={authModalView}
      />
    </header>
  );
}
