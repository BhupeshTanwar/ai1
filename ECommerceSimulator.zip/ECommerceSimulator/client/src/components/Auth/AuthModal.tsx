import { useState } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogTitle,
  DialogDescription,
  DialogHeader
} from "@/components/ui/dialog";
import { LoginForm } from "./LoginForm";
import { SignupForm } from "./SignupForm";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultView?: "login" | "signup";
}

export function AuthModal({ isOpen, onClose, defaultView = "login" }: AuthModalProps) {
  const [view, setView] = useState<"login" | "signup">(defaultView);

  const handleSuccess = () => {
    onClose();
  };

  const switchToLogin = () => {
    setView("login");
  };

  const switchToSignup = () => {
    setView("signup");
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>
            {view === "login" ? "Sign In to AmaStore" : "Create an Account"}
          </DialogTitle>
          <DialogDescription>
            {view === "login" 
              ? "Enter your credentials to access your account" 
              : "Sign up to start shopping on AmaStore"}
          </DialogDescription>
        </DialogHeader>
        
        {view === "login" ? (
          <LoginForm onSuccess={handleSuccess} onRegisterClick={switchToSignup} />
        ) : (
          <SignupForm onSuccess={handleSuccess} onLoginClick={switchToLogin} />
        )}
      </DialogContent>
    </Dialog>
  );
}