import { useState } from "react";
import { Product } from "@/lib/types";
import { ProductCard } from "./ProductCard";
import { Button } from "@/components/ui/button";

interface ProductGridProps {
  products: Product[];
  searchQuery: string;
  onAddToCart: (product: Product) => void;
  onViewProduct: (product: Product) => void;
}

export function ProductGrid({ 
  products, 
  searchQuery, 
  onAddToCart, 
  onViewProduct 
}: ProductGridProps) {
  const [filteredProducts, setFilteredProducts] = useState<Product[]>(products);
  const [isSearchActive, setIsSearchActive] = useState(false);

  // Filter products when search query changes
  useState(() => {
    if (searchQuery.trim() === "") {
      setFilteredProducts(products);
      setIsSearchActive(false);
      return;
    }

    const filtered = products.filter(
      (product) =>
        product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    setFilteredProducts(filtered);
    setIsSearchActive(true);
  });

  const clearSearch = () => {
    setFilteredProducts(products);
    setIsSearchActive(false);
  };

  return (
    <div className="mb-6">
      <h2 className="text-2xl font-bold mb-4">Featured Products</h2>
      
      {/* Search Status */}
      {isSearchActive && (
        <div className="mb-4">
          <p>
            Showing results for: <span className="font-semibold">{searchQuery}</span>
          </p>
          <Button 
            variant="link" 
            className="text-blue-600 p-0 h-auto"
            onClick={clearSearch}
          >
            Clear search
          </Button>
        </div>
      )}
      
      {/* Product Grid */}
      {filteredProducts.length === 0 ? (
        <div className="col-span-full text-center py-10 text-gray-500">
          No products found matching your search.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={onAddToCart}
              onViewProduct={onViewProduct}
            />
          ))}
        </div>
      )}
    </div>
  );
}
