import { Star, StarHalf } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Product } from "@/lib/types";

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onViewProduct: (product: Product) => void;
}

export function ProductCard({ product, onAddToCart, onViewProduct }: ProductCardProps) {
  // Generate star rating
  const renderStarRating = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const stars = [];
    
    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="w-4 h-4 fill-yellow-400 text-yellow-400" />);
    }
    
    // Add half star if needed
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="w-4 h-4 fill-yellow-400 text-yellow-400" />);
    }
    
    // Add empty stars
    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="w-4 h-4 text-yellow-400" />);
    }
    
    return stars;
  };

  return (
    <Card className="product-card overflow-hidden">
      <CardContent className="p-4">
        <div 
          className="mb-4 cursor-pointer" 
          onClick={() => onViewProduct(product)}
        >
          <img 
            src={product.image} 
            alt={product.title} 
            className="w-full h-48 object-contain"
          />
        </div>
        <div className="cursor-pointer" onClick={() => onViewProduct(product)}>
          <h3 className="font-medium text-gray-900 mb-2 hover:text-[#232f3e] line-clamp-2">
            {product.title}
          </h3>
          <div className="flex items-center mb-2">
            {renderStarRating(product.rating)}
            <span className="text-gray-600 ml-1 text-sm">({product.rating})</span>
          </div>
          <div className="amazon-price text-lg mb-3">
            ${product.price.toFixed(2)}
          </div>
        </div>
        <Button 
          className="w-full amazon-accent"
          onClick={() => onAddToCart(product)}
        >
          Add to Cart
        </Button>
      </CardContent>
    </Card>
  );
}
